import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-primary">
      Hello from Component One
    </h1>
  `,
  styles: [
  ]
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
