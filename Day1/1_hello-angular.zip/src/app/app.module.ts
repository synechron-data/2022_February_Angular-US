// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';
// import { HiComponent } from './components/hi/hi.component';

// @NgModule({
//   declarations: [
//     HelloComponent,
//     HiComponent
//   ],
//   imports: [
//     BrowserModule
//   ],
//   providers: [],
//   bootstrap: [
//     HiComponent
//   ]
// })
// export class AppModule { }

// ----------------------------------------------------------------------- Default Bootstrapping

// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';
// import { HiComponent } from './components/hi/hi.component';

// @NgModule({
//   declarations: [
//     HelloComponent,
//     HiComponent
//   ],
//   imports: [
//     BrowserModule
//   ],
//   providers: [],
//   bootstrap: [
//     HelloComponent,
//     HiComponent
//   ]
// })
// export class AppModule { }

// ----------------------------------------------------------------------- Manual Bootstrapping

import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';
import { HiComponent } from './components/hi/hi.component';

@NgModule({
  declarations: [
    HelloComponent,
    HiComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: []
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    let condition = true;

    const app = document.querySelector("#app");

    if (condition) {
      const helloTag = document.createElement('app-hello');
      app?.appendChild(helloTag);
      appRef.bootstrap(HelloComponent);
    } else {
      const hiTag = document.createElement('app-hi');
      app?.appendChild(hiTag);
      appRef.bootstrap(HiComponent);
    }
  }
}