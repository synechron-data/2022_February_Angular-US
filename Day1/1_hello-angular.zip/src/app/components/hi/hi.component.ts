import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hi',
  template: `
    <h1>
      Hi works!
    </h1>
  `
})
export class HiComponent { }
