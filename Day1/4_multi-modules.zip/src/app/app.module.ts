import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MyLibModule } from 'my-lib';
import { RootComponent } from './components/root/root.component';
import { MoneModule } from './mone/mone.module';
import { MtwoModule } from './mtwo/mtwo.module';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    RootComponent
  ],
  imports: [
    BrowserModule,
    MoneModule,
    MtwoModule,
    SharedModule,
    MyLibModule
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }