import { AfterViewChecked, AfterViewInit, Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements AfterViewInit, AfterViewChecked {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  name: string;
  greetings: string;
  count: number;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World";
    this.flag = false;
    this.h = 300;
    this.w = 300;
    this.name = "";
    this.greetings = "";
    this.count = 0;
  }
  
  ngAfterViewChecked(): void {
    console.log('Change detection triggered!');
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS")?.addEventListener("click", () => {
    //   this.message = new Date().toLocaleTimeString();
    //   console.log(this.message);
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS")?.addEventListener("click", () => {
        this.message = new Date().toLocaleTimeString();
        console.log(this.message);
      });
    });
  }

  increaseCount(cb: () => void) {
    this.count += 1;
    if (this.count < 50) {
      window.setTimeout(() => {
        this.increaseCount(cb);
      }, 100);
    } else {
      cb();
    }
  }

  inZone() {
    this.count = 0;
    this.message = "Started...";
    this.increaseCount(() => {
      this.message = "Completed...";
    });
  }

  outOfZone() {
    this.count = 0;
    this.message = "Started...";

    this.ngZone.runOutsideAngular(() => {
      this.increaseCount(() => {
        this.ngZone.run(() => {
          this.message = "Completed...";
        });
      });
    })
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorHandler1() {
    alert("Anchor was clicked...");
  }

  anchorHandler2(e: Event) {
    alert("Anchor was clicked...");
    e.preventDefault();
  }

  doUpdate(n: string) {
    this.greetings = `Hello, ${n}`;
  }
}