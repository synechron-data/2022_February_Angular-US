// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';

// @Component({
//     selector: 'app-root',
//     templateUrl: './root.component.html'
// })
// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// // ----------------------------------------------------------

// import { HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';
// import { PostsService } from 'src/app/services/posts.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: './root.component.html',
//     providers: [PostsService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private postsService: PostsService) {
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// ----------------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.model';
import { PostsService } from 'src/app/services/posts.service';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    providers: [PostsService]
})
export class RootComponent implements OnInit, OnDestroy {
    message: string;
    posts?: Array<Post>;
    get_sub?: Subscription;

    constructor(private postsService: PostsService) {
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
            this.posts = [...resData];
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.get_sub?.unsubscribe();
    }
}