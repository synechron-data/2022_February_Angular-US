import { Component, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';
import { AuthorService } from 'src/app/services/author.service';

@Component({
  selector: 'author-quote',
  templateUrl: './author-quote.component.html',
  styleUrls: ['./author-quote.component.css']
})
export class AuthorQuoteComponent implements OnInit {
  selectedAuthor?: Author;

  constructor(private authorService: AuthorService) { }

  ngOnInit(): void {
  }

  getQuote() {
    this.selectedAuthor = this.authorService.SelectedAuthor;
  }
}
