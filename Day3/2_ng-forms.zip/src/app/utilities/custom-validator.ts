// import { AbstractControl, ValidationErrors } from "@angular/forms";

// export class CustomValidators {
//     static ageRange(control: AbstractControl): ValidationErrors | null {
//         if (control.value !== '' && (isNaN(control.value) || control.value < 20 || control.value > 60)) {
//             return { 'ageRange': true };
//         } else {
//             return null;
//         }
//     }
// }

// --------------------------------------------------------

import { AbstractControl, AsyncValidatorFn, ValidationErrors, ValidatorFn } from "@angular/forms";
import { Observable, of } from "rxjs";
import { delay, map } from "rxjs/operators";

export class CustomValidators {
    static ageRange(min = 20, max = 60): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            if (control.value !== '' && (isNaN(control.value) || control.value < min || control.value > max)) {
                return { 'ageRange': true };
            } else {
                return null;
            }
        }
    }

    private static takenUsernames = [
        'manish',
        'manishs',
        'manishsharma',
        'manish.sharma',
        'manish_sharma'
    ];

    private static checkIfUsernameExists(username: string): Observable<boolean> {
        // HTTP API call
        return of(CustomValidators.takenUsernames.includes(username)).pipe(delay(1000));
    }

    static usernameValidator(): AsyncValidatorFn {
        return (control: AbstractControl): Observable<ValidationErrors | null> => {
            return CustomValidators.checkIfUsernameExists(control.value).pipe(
                map(res => {
                    // if res is true, username exists, return true
                    return res ? { 'usernameExists': true } : null;
                    // Return null if there is no error
                })
            )
        }
    }
}