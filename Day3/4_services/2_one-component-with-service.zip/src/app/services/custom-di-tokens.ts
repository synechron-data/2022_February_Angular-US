import { InjectionToken } from "@angular/core";

export const Authors = new InjectionToken<string>("AuthorsListDIToken");