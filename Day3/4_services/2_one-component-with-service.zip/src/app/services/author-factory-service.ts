import { AuthorService } from "./author.service";
import { NAuthorService } from "./nauthor.service";

export function AuthorFactoryService(enviornment: any) {
    if (enviornment['production'])
        return new AuthorService();
    else
        return new NAuthorService();
}